

    $('#switch1').change(function() {
        console.log("change");       
    });
